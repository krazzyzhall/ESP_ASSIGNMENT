 here Squeue.c is the file for driver
i686_make makefile od for making the source for host linux system using command 'make i686'

for building the kernel for poky linux(Galileo board) run 'make clanton'
