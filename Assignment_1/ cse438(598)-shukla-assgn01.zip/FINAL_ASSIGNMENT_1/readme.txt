there are three folders :
1)Dynamic: it has code for dynamic implementation 
2)Static :it has implementation of static queue
3) Report has performance report of dynamic and Static

there is a driver code in Squeue.c
which implements driver for Shared Queue

there is main2.c which implements tester code with 7 threads :3 reader 1 Deamon 3 Sender 

Note: for making it for Galileo Mac=kefile's KDIR and SROOT may be required to change appropriately  
