static_ptrint : perf report generated while using static implementation and printing the messages
Dynamic_print : perf report generated while using dynamic implementation and printing the messages 
